const { clearFileDir } = require('./server');

console.log('clearing test files...');
clearFileDir();
console.log('done');
